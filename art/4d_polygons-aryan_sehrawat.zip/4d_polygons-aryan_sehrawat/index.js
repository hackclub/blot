/*
@title: 4d_polygons
@author: aryanSehrawat
@snapshot: 4-d polygons
*/

const width = 1200;
const height = 800;
setDocDimensions(width, height);

const numColumns = 30;
const numRows = 40;
const interpolationSteps = 15;

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function generateColumnPoints() {
  const allColumnsPoints = [];
  for (let row = 0; row < numRows; row++) {
    const columnPoints = [];
    for (let col = 0; col < numColumns; col++) {
      const x = row * width / numRows + bt.randInRange(0, 0.8 * width / numRows);
      const y = col * height / numColumns + bt.randInRange(0, 0.6 * height / numColumns);
      columnPoints.push([x <= width ? x : width, y <= height ? y : height]);
    }
    allColumnsPoints.push(columnPoints);
  }
  return allColumnsPoints;
}

const allColumnsPoints = generateColumnPoints();

function interpolateAndDraw(currentColumnPoints, nextColumnPoints) {
  for (let step = 0; step < interpolationSteps; step++) {
    const t = step / interpolationSteps;
    for (let i = 0; i < currentColumnPoints.length - 1; i++) {
      const x1 = lerp(currentColumnPoints[i][0], nextColumnPoints[i][0], t);
      const y1 = lerp(currentColumnPoints[i][1], nextColumnPoints[i][1], t);
      const x2 = lerp(currentColumnPoints[i + 1][0], nextColumnPoints[i + 1][0], t);
      const y2 = lerp(currentColumnPoints[i + 1][1], nextColumnPoints[i + 1][1], t);
      drawLines([
        [
          [x1, y1],
          [x2, y2]
        ]
      ]);
    }
  }
}

for (let index = 0; index < allColumnsPoints.length - 1; index++) {
  const currentColumnPoints = allColumnsPoints[index];
  const nextColumnPoints = allColumnsPoints[index + 1];
  interpolateAndDraw(currentColumnPoints, nextColumnPoints);
}

console.log("Interpolated polygons drawn.");