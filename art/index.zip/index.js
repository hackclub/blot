const width = 150;
const height = 300;

setDocDimensions(width, height);

const cupHeight = 200;
const cupWidth = 100;
const strawWidth = 12;
const strawHeight = 120;
const tapiocaSize = 10;

const finalLines = [];

// Create the cup with rounded corners for a softer look
const cup = bt.nurbs([
  [10, 0], // Start at the top-left with rounded corners
  [cupWidth - 10, 0],
  [cupWidth, 10], // Round the top-right corner
  [cupWidth, cupHeight - 20],
  [cupWidth - 10, cupHeight],
  [10, cupHeight], // Round the bottom-left corner
  [0, cupHeight - 20],
]);

// Create tapioca pearls with random positions to add cuteness
const tapiocaPearl = (x, y) => bt.nurbs([
  [x, y], 
  [x + tapiocaSize, y + tapiocaSize], 
  [x + tapiocaSize * 1.5, y], 
  [x + tapiocaSize, y - tapiocaSize],
  [x, y]
]);

const tapioca1 = tapiocaPearl(30, cupHeight - 40);
const tapioca2 = tapiocaPearl(55, cupHeight - 50);
const tapioca3 = tapiocaPearl(80, cupHeight - 60);
const tapioca4 = tapiocaPearl(45, cupHeight - 80);
const tapioca5 = tapiocaPearl(65, cupHeight - 90);

finalLines.push(tapioca1, tapioca2, tapioca3, tapioca4, tapioca5);

// Create a more curved straw for cuteness
const straw = bt.nurbs([
  [cupWidth / 2, cupHeight + 10],
  [cupWidth / 2 + 5, cupHeight + strawHeight / 2],
  [cupWidth / 2, cupHeight + strawHeight + 20]
]);

finalLines.push(cup, straw);

const finalBounds = bt.bounds(finalLines);
const finalScale = width / finalBounds.width * 0.85;
bt.scale(finalLines, finalScale);
bt.translate(finalLines, [width / 2, height / 2], bt.bounds(finalLines).cc);

// Draw the lines with no color (default black outline)
drawLines(finalLines);
